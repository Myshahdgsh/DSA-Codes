#include <bits/stdc++.h>
using namespace std;

struct Item
{
    int itemNo;
    float quantity, profit, pwprofit; // profit per weight
};

// comparator for sorting by profit per weight (descending)
bool compare(Item a, Item b)
{
    return a.pwprofit > b.pwprofit;
}

int main()
{
    cout << "Enter Number of items: ";
    int n;
    cin >> n;
    Item items[n];

    cout << "Enter Items (Item No, Quantity, Profit):\n";
    for (int i = 0; i < n; i++)
    {
        cin >> items[i].itemNo >> items[i].quantity >> items[i].profit;
        items[i].pwprofit = items[i].profit / items[i].quantity;
    }

    // sort items by profit per weight
    sort(items, items + n, compare);

    cout << "Enter capacity: ";
    float capacity;
    cin >> capacity;

    float profit = 0, capacity_left = capacity;

    cout << "\nSelected Items:\n";
    for (int i = 0; i < n; i++)
    {
        if (capacity_left <= 0)
            break;

        if (items[i].quantity <= capacity_left)
        {
            // take full item
            profit += items[i].profit;
            capacity_left -= items[i].quantity;
            cout << "Item No. " << items[i].itemNo << " | Quantity: " << items[i].quantity << "\n";
        }
        else
        {
            // take fractional item
            profit += capacity_left * items[i].pwprofit;
            cout << "Item No. " << items[i].itemNo << " | Quantity: " << capacity_left << "\n";
            capacity_left = 0;
        }
    }

    cout << "\nMaximum profit within capacity " << capacity << " is: " << profit << "\n";
    return 0;
}
