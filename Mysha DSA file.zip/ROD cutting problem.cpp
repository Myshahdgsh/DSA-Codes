#include<bits/stdc++.h>
using namespace std;

int main()
{
    int l;  // length of rod
    cin >> l;

    int profit[l+1];  // profit[i] = profit of rod length i
    for(int i=0; i<=l; i++)
    {
        cin >> profit[i];
    }

    // 2D DP table
    int dp[l+1][l+1];

    // Build DP table
    for(int i=0; i<=l; i++)
    {
        for(int j=0; j<=l; j++)
        {
            if(i==0 || j==0)
            {
                dp[i][j] = 0;
            }
            else if(j < i)
            {
                dp[i][j] = dp[i-1][j];
            }
            else
            {
                dp[i][j] = max(dp[i-1][j], profit[i] + dp[i][j-i]);
            }
        }
    }

    cout << "Maximum profit is: " << dp[l][l] << endl;

    // ---- Print the cuts used ----
    cout << "Rod cuts are: ";
    int i = l, j = l;
    while(i > 0 && j > 0)
    {
        if(dp[i][j] == dp[i-1][j]) {
            i--; // this length not used
        }
        else {
            cout << i << " "; // cut of length i
            j -= i;
        }
    }
    cout << endl;

    return 0;
}
