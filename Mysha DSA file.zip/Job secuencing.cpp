#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

class Job{
    int ID, deadline, profit;
};
bool compare(Job a, Job b)
{
    return a.profi>b.profit;
}
int main()
{
    int n;
    cout<<"Enter the Number of Jobs: ";
    cin>>n;
    vector<job>jobs(n);

}
